-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 30, 2023 at 08:10 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `horizon`
--

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE `application` (
  `name` varchar(20) NOT NULL,
  `gender` text NOT NULL,
  `age` int(2) DEFAULT NULL,
  `email` varchar(20) NOT NULL,
  `phone` int(10) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL,
  `pin_code` varchar(6) NOT NULL,
  `country` varchar(20) NOT NULL,
  `date` int(20) NOT NULL,
  `prefered_slot` int(20) NOT NULL,
  `prefered_Test` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `application`
--

INSERT INTO `application` (`name`, `gender`, `age`, `email`, `phone`, `address`, `city`, `state`, `pin_code`, `country`, `date`, `prefered_slot`, `prefered_Test`) VALUES
('adi', 'Male', 21, 'thorataditya859@gmai', 1234567890, 'Nityanand nagar , HIngwala plot, paravatibai chawl, ghatkopar-west ,mumbai', 'Mumbai', 'Maharashtra', '400075', 'India', 22042023, 14, 'Heart'),
('Ashok', 'Male', 58, 'thorataditya859@gmai', 2147483647, 'paravati bai chawl, nityananad nagar ,hingwala plot,LBS road, ghatkopar east', 'Mumbai', 'Maharashtra', '400086', 'India', 21042023, 14, 'Kindey_function_test'),
('Ashok Mahatarba Thor', 'Male', 19, 'vu1f2122013@pvppcoe.', 2147483647, 'paravati bai chawl, nityananad nagar ,hingwala plot,LBS road, ghatkopar east', 'Mumbai', 'Maharashtra', '400086', 'India', 18082023, 13, 'Thyroid'),
('sagar', 'male', 21, 'sagarsunka@gmail.com', 2147483647, 'ghar', 'mumbai', 'Maharashtra', '400001', 'India', 2002, 14, 'Heart'),
('vaishali thorat ', 'female', 37, 'vashalithora244@gmai', 2147483647, 'Shiv prasad  CHS , Laxmi Nagar, Ghatkopar(E)', 'Mumbai', 'Maharashtra', '400075', 'India', 1995, 15, 'Thyroid');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `username` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`username`, `email`, `password`) VALUES
('yash', 'vu1f2122013@pvppcoe.', 'password'),
('yash', '', 'password'),
('yash', '', 'password'),
('yash', '', 'password'),
('yash', '', 'password'),
('yash', '', 'password'),
('yash', '', 'password'),
('yash', '', 'password'),
('yash', '', 'password'),
('aditya', 'thoratashok68@gmail.', 'pass'),
('aditya', '', 'pass'),
('aditya', '', 'pass'),
('aditya', '', 'pass'),
('aditya', '', 'pass'),
('aditya', '', 'pass'),
('aditya', '', 'pass'),
('aditya', '', 'passs'),
('aditya', '', 'passsss'),
('', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `application`
--
ALTER TABLE `application`
  ADD PRIMARY KEY (`name`),
  ADD UNIQUE KEY `Email` (`email`,`phone`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
